G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.2*
G04 #@! TF.CreationDate,2026-04-29T22:50:09+10:00*
G04 #@! TF.ProjectId,daughter-board,64617567-6874-4657-922d-626f6172642e,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.2) date 2026-04-29 22:50:09*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X-0.650000X-1.550000X0.650000X-1.550000X0.650000X1.550000X-0.650000X1.550000X0*%
%ADD11O,1.800000X3.600000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X119750000Y-78300000D03*
D11*
X123560000Y-78300000D03*
X127370000Y-78300000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J5*
X145850000Y-78350000D03*
D11*
X149660000Y-78350000D03*
X153470000Y-78350000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J3*
X132800000Y-78350000D03*
D11*
X136610000Y-78350000D03*
X140420000Y-78350000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J6*
X139422500Y-92007500D03*
D11*
X143232500Y-92007500D03*
X147042500Y-92007500D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J4*
X125600000Y-92000000D03*
D11*
X129410000Y-92000000D03*
X133220000Y-92000000D03*
G04 #@! TD*
M02*
